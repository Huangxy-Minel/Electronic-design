#ifndef GPIO_H
#define GPIO_H
#include "sys.h"

void GPIO_ALLInit(void);//IO口配置

#endif
